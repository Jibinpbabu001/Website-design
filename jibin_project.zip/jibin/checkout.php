<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
    .card1{
        width:120px;
        height: 120px;
    }
    
    
    .foot{
        background-color: #263238;
        color: aliceblue;
        height: 50px;
        text-align: center;
        vertical-align: middle;
    }
    
ul.topnav {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

    
ul.topnav li {float: left;}

ul.topnav li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

ul.topnav li a:hover:not(.active) {background-color: #111;}

ul.topnav li a.active {background-color: #4CAF50;}

ul.topnav li.right {float: right;}

@media screen and (max-width: 600px) {
  ul.topnav li.right, 
  ul.topnav li {float: none;}
}
</style>
    </head>
    <body>

<ul class="topnav">
  <li><a  href="store_index.php">Home</a></li>
  <li><a class="active">Products</a></li>
</ul>

<div style="padding-top:50px; padding-bottom:50px">
<?php
session_start();
require('mysqli_connect.php');

$pr_id= $_GET['id'];
$q = "SELECT * FROM products WHERE p_id = {$_GET['id']}";
$r = @mysqli_query($dbc,$q);

while ($row = mysqli_fetch_array($r, MYSQLI_ASSOC)) {
    $_SESSION['p_id'] = $row['p_id'];
    $_SESSION['p_name'] = $row['p_name'];
    $_SESSION['quantity'] = $row['quantity'];
}



?>

<?php
    
echo '<form action="confirmation.php?id=' .$_SESSION['p_id']. '&qua=' .$_SESSION['quantity']. '" method="post">
 
    <p>First Name: <input type="text" name="first_name" required="required"> </p>
    <p>Last Name: <input type="text" name="last_name" required="required"></p>
    
<label for="pay">Payment: </label>

<div>
  <input type="radio" id="credit" name="payment" value="creditcard" required="required">
  <label for="credit">Credit Card</label>
  
</div>

<div>
  <input type="radio" id="debit" name="payment" value="debitcard">
  
  <label for="debitcard">Debit Card</label>
</div>
<div>
<label for="ccnum">Credit card number</label>
            <input type="text" id="ccnum" name="cardnumber" placeholder="1111-2222-3333-4444" required="required">
            <label for="expmonth">Exp Month</label>
            <input type="text" id="expmonth" name="expmonth" placeholder="September" required="required">
</div>
	<p>	<input type="submit" value="submit">
		</p>
		
			
</form>'
?>

</div>
    
    </body>
    <footer><div class="foot">© 2018 Copyright:
        <a href="https://mdbootstrap.com/education/bootstrap/"> E-store</a></div></footer>
</html>
