INSERT INTO `products` (`p_id`, `p_name`, `quantity`, `image`, `price`) VALUES
(1, 't-shirt', 9, 'abc.jpg', 10),
(2, 'shirt', 3, 'bcd.jpg', 12),
(3, 'jersey', 8, 'def.jpg', 14),
(4, 'jacket', 3, 'efg.jpg', 16),
(5, 'jeans', 5, 'fgh.jpg', 35),
(6, 'shoes', 7, 'ghi.jpg', 23);


