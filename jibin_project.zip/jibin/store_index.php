<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>

    #desc{
      
        padding-bottom: 75px;
        margin-left: auto;
        margin-right: auto;
        align-content: center;
        text-align: center;
        width: 1200px;
        height:150px;
    }
    .foot{
        background-color: #263238;
        color: aliceblue;
        height: 50px;
        text-align: center;
        vertical-align: middle;
    }
.mySlides {display:none}
.w3-left, .w3-right, .w3-badge {cursor:pointer}
.w3-badge {height:13px;width:13px;padding:0}
body {margin: 0;}

ul.topnav {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

ul.topnav li {float: left;}

ul.topnav li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

ul.topnav li a:hover:not(.active) {background-color: #111;}

ul.topnav li a.active {background-color: #4CAF50;}

ul.topnav li.right {float: right;}

@media screen and (max-width: 600px) {
  ul.topnav li.right, 
  ul.topnav li {float: none;}
}
</style>
    
</head>
<body>

<ul class="topnav">
  <li><a class="active" href="#home">Home</a></li>
  <li><a href="store.php">Products</a></li>
</ul>
    
<div style="padding-top:25px; padding-bottom:30px">
<div class="w3-content w3-display-container" style="max-width:1700px">
    <a href="store.php"><img class="mySlides" src="fossil-watches-banner.jpg" style="width:100%; height:420px"></a>
    <a href="store.php"><img class="mySlides" src="next.jpg" style="width:100%; height:420px"></a>
        <a href="store.php"><img class="mySlides" src="homepage-Chuck-II-Refresh-1600x540.jpg" style="width:100%; height:420px"></a>
   
        <a href="store.php"><img class="mySlides" src="tissot-banner2.jpg" style="width:100% ; height:420px"></a>
  <div class="w3-center w3-container w3-section w3-large w3-text-white w3-display-bottommiddle" style="width:100%">
    <div id="leftarrow" class="w3-left w3-hover-text-khaki" onclick="plusDivs(-1)">&#10094;</div>
    <div id="rightarrow" class="w3-right w3-hover-text-khaki" onclick="plusDivs(1)">&#10095;</div>
    <span class="w3-badge demo w3-border w3-transparent w3-hover-white" onclick="currentDiv(1)"></span>
    <span class="w3-badge demo w3-border w3-transparent w3-hover-white" onclick="currentDiv(2)"></span>
    <span class="w3-badge demo w3-border w3-transparent w3-hover-white" onclick="currentDiv(3)"></span>
     
      <span class="w3-badge demo w3-border w3-transparent w3-hover-white" onclick="currentDiv(4)"></span>
  </div>
</div>

<script>
var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
  showDivs(slideIndex += n);
}

function currentDiv(n) {
  showDivs(slideIndex = n);
}

function showDivs(n) {
  var i;
  var x = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("demo");
  if (n > x.length) {slideIndex = 1}
  if (n < 1) {slideIndex = x.length}
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" w3-white", "");
  }
  x[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " w3-white";
}
</script>
</div>
    
    <div id="desc">
        
        <p>STYLISH, MODERN WATCHES, HANDBAGS & JEWELRY TO PUT A FINISHING TOUCH ON YOUR OUTFIT
If you're shopping for the perfect watch, handbag, piece of jewelry or other accessory, you've come to a great place. At E-store, we're inspired by all things classic and vintage, but we love updating our products with a modern touch so that they're perfect confidants to the bright and busy men and women who wear them. And whether you're a guy who prefers masculine details and an industrial-looking leather strap or a lady who likes glitzy rose-gold tone timepieces and bold, elegant handbags, there's the perfect find among our collection of watches, bags and accessories for you to make your own.</p>
        
    </div>
    <div class="w3-container" style="margin-left: auto;
    margin-right: auto; width: 100em">
  <h2>Smartwatches</h2>
  <table class="w3-table" style="height:10px; padding-top:150px;" >
    
    <tr>
      <td  ><div class="w3-container">
  
  <div class="w3-card-4" style="width:70%">
    <img src="fossil-6113-729919-1.jpg" alt="Alps" style="width:100%">
    <div class="w3-container w3-center">
      <h5>GEN 5 SMARTWATCH</h5>
        <p>S$ 489.00</p>
        
        <p>Silicone strap</p>
        <p>Stainless steel case </p>
        <a href="store.php"><button>go to products</button></a>
    </div>
  </div>
</div></td>
      <td ><div class="w3-container">
 

  <div class="w3-card-4" style="width:70%">
    <img src="204985115_9999_6A8D36C298F040539DFDF80A9AF35A56.jpg" alt="Alps" style="width:100%">
    <div class="w3-container w3-center">
      
        <h5>GEN 3 SMARTWATCH</h5>
        <p>S$ 309.00</p>
        
        <p>Silicone strap</p>
        <p>Stainless steel case </p>
        <a href="store.php"><button>go to products</button></a>
    </div>
  </div>
</div></td>
      <td ><div class="w3-container">
 
  <div class="w3-card-4" style="width:70%">
    <img src="fossil-0704-687909-1.jpg" alt="Alps" style="width:100%">
    <div class="w3-container w3-center">
      <h5>GEN 4 SMARTWATCH</h5>
        <p>S$ 409.00</p>
        
        <p>Silicone strap</p>
        <p>Stainless steel case </p>
        <a href="store.php"><button >go to products</button></a>
    </div>
  </div>
</div></td>
    </tr>
    
  </table>
        
</div>
    <div><a href="store.php"><img src="banner.jpg" style=" left: auto; right: auto; width: 100% "></a>
   </div>
</body>
    <footer><div class="foot">© 2018 Copyright:
        <a href="https://mdbootstrap.com/education/bootstrap/"> E-store</a></div></footer>
</html>


<?php
?>